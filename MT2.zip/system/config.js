module.exports = {
  BOT_TOKEN:
  "7918078346:AAFOpLFgLE1iC5NDMOh9aQSdI1IbsBfXuzw",
};

