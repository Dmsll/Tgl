#Creator : ArgaOffc

#INFORMATION : Scrip Ini Di Rakit Oleh ArgaOffc, Tujuanya Adalah Untuk Membasmi Para Sampah Seperti riper Kang nahan duit, Contohnya AlwaysKayzen/Indra Padahal Mah 35k, Dev Kacung😂 Upsss,Intinya Jadi Jangan Disalah Gunakan Ya Gunakanlah Dengan Bijak🔥

#UNTUK BUG FORCLOSE APA BILA TIDAK BERPENGARUH SILAHKAN GUNAKAN WA BETA KARANA SAYA MENGUJINYA DI WA BETA

#JIKA ADA KE ERORAN MAKA LAPOR KE t.me/ArgaOffc

#SALURAN WHATSAPP CRATOR : 
https://whatsapp.com/channel/0029Vay4hgh2Jl8J4yIOIA3i